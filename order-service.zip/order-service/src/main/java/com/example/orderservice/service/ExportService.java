package com.example.orderservice.service;

import com.example.orderservice.domain.entity.Order;
import com.example.orderservice.dto.ExportResponse;
import com.example.orderservice.dto.OrderExportSummary;
import com.example.orderservice.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ExportService {
    private static final DateTimeFormatter FILE_STAMP = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private static final String CSV_HEADER = "id,orderNumber,customerId,status,totalAmount,itemCount,createdAt";

    private final OrderRepository orderRepository;

    /**
     * Export orders, optionally restricted to a creation-date range, as either
     * structured JSON summaries or a CSV document (KAN-6).
     *
     * @param format   {@code json} or {@code csv} (case-insensitive)
     * @param fromDate inclusive lower bound on {@code createdAt}; {@code null} means unbounded
     * @param toDate   inclusive upper bound on {@code createdAt}; {@code null} means unbounded
     * @throws IllegalArgumentException if the range is inverted or the format is unknown
     */
    public ExportResponse exportOrders(String format, LocalDateTime fromDate, LocalDateTime toDate) {
        if (fromDate != null && toDate != null && fromDate.isAfter(toDate)) {
            throw new IllegalArgumentException("fromDate must not be after toDate");
        }

        List<OrderExportSummary> summaries = orderRepository.findAll().stream()
                .filter(order -> withinRange(order.getCreatedAt(), fromDate, toDate))
                .map(this::toSummary)
                .toList();

        String normalized = format == null ? "csv" : format.trim().toLowerCase();
        String stamp = LocalDateTime.now().format(FILE_STAMP);
        return switch (normalized) {
            case "json" -> ExportResponse.builder()
                    .fileName("orders-export-" + stamp + ".json")
                    .contentType("application/json")
                    .recordCount(summaries.size())
                    .orders(summaries)
                    .build();
            case "csv" -> ExportResponse.builder()
                    .fileName("orders-export-" + stamp + ".csv")
                    .contentType("text/csv")
                    .recordCount(summaries.size())
                    .content(toCsv(summaries))
                    .build();
            default -> throw new IllegalArgumentException("Unsupported export format: " + format + " (expected 'json' or 'csv')");
        };
    }

    private boolean withinRange(LocalDateTime createdAt, LocalDateTime fromDate, LocalDateTime toDate) {
        if (createdAt == null) {
            return false;
        }
        return (fromDate == null || !createdAt.isBefore(fromDate))
                && (toDate == null || !createdAt.isAfter(toDate));
    }

    private OrderExportSummary toSummary(Order order) {
        return OrderExportSummary.builder()
                .id(order.getId())
                .orderNumber(order.getOrderNumber())
                .customerId(order.getCustomer() == null ? null : order.getCustomer().getId())
                .status(order.getStatus() == null ? null : order.getStatus().name())
                .totalAmount(order.getTotalAmount())
                .itemCount(order.getItems() == null ? 0 : order.getItems().size())
                .createdAt(order.getCreatedAt())
                .build();
    }

    private String toCsv(List<OrderExportSummary> summaries) {
        StringBuilder csv = new StringBuilder(CSV_HEADER).append('\n');
        for (OrderExportSummary s : summaries) {
            csv.append(nullToEmpty(s.getId())).append(',')
                    .append(csvEscape(s.getOrderNumber())).append(',')
                    .append(nullToEmpty(s.getCustomerId())).append(',')
                    .append(csvEscape(s.getStatus())).append(',')
                    .append(nullToEmpty(s.getTotalAmount())).append(',')
                    .append(s.getItemCount()).append(',')
                    .append(nullToEmpty(s.getCreatedAt())).append('\n');
        }
        return csv.toString();
    }

    private String nullToEmpty(Object value) {
        return value == null ? "" : value.toString();
    }

    /** Minimal RFC-4180 escaping: quote fields containing comma, quote or newline. */
    private String csvEscape(String value) {
        if (value == null) {
            return "";
        }
        if (value.contains(",") || value.contains("\"") || value.contains("\n") || value.contains("\r")) {
            return '"' + value.replace("\"", "\"\"") + '"';
        }
        return value;
    }
}
