package com.example.orderservice.service;

import com.example.orderservice.domain.entity.InventoryItem;
import com.example.orderservice.domain.entity.Product;
import com.example.orderservice.dto.InventoryResponse;
import com.example.orderservice.dto.InventoryUpdateRequest;
import com.example.orderservice.exception.InsufficientStockException;
import com.example.orderservice.exception.ResourceNotFoundException;
import com.example.orderservice.repository.InventoryRepository;
import com.example.orderservice.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class InventoryService {
    private final InventoryRepository inventoryRepository;
    private final ProductRepository productRepository;

    @Transactional
    public InventoryResponse adjustStock(InventoryUpdateRequest request) {
        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + request.getProductId()));
        InventoryItem inventoryItem = inventoryRepository.findByProduct(product)
                .orElseGet(() -> inventoryRepository.save(InventoryItem.builder().product(product).availableQuantity(0).build()));
        inventoryItem.setAvailableQuantity(inventoryItem.getAvailableQuantity() + request.getQuantity());
        InventoryItem saved = inventoryRepository.save(inventoryItem);
        return toResponse(saved);
    }

    @Transactional
    public void reserveStock(Long productId, int quantity) {
        InventoryItem inventoryItem = inventoryRepository.findByProductId(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found for product id: " + productId));
        if (inventoryItem.getAvailableQuantity() < quantity) {
            throw new InsufficientStockException("Insufficient stock for product id: " + productId);
        }
        inventoryItem.setAvailableQuantity(inventoryItem.getAvailableQuantity() - quantity);
        inventoryRepository.save(inventoryItem);
    }

    public InventoryResponse getInventory(Long productId) {
        InventoryItem inventoryItem = inventoryRepository.findByProductId(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found for product id: " + productId));
        return toResponse(inventoryItem);
    }

    private InventoryResponse toResponse(InventoryItem inventoryItem) {
        return InventoryResponse.builder()
                .productId(inventoryItem.getProduct().getId())
                .sku(inventoryItem.getProduct().getSku())
                .availableQuantity(inventoryItem.getAvailableQuantity())
                .build();
    }
}
