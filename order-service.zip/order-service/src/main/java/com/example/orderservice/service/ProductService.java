package com.example.orderservice.service;

import com.example.orderservice.domain.entity.InventoryItem;
import com.example.orderservice.domain.entity.Product;
import com.example.orderservice.dto.ProductCreateRequest;
import com.example.orderservice.dto.ProductResponse;
import com.example.orderservice.dto.ProductUpdateRequest;
import com.example.orderservice.exception.ResourceNotFoundException;
import com.example.orderservice.repository.InventoryRepository;
import com.example.orderservice.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ProductService {
    private final ProductRepository productRepository;
    private final InventoryRepository inventoryRepository;

    /**
     * Default stock a new product's inventory is seeded with when the create
     * request does not specify an initial stock level. Configurable via
     * {@code order-service.inventory.default-initial-stock}; defaults to 100 so
     * that newly created products are immediately orderable (KAN-4).
     */
    @Value("${order-service.inventory.default-initial-stock:100}")
    private int defaultInitialStock;

    @Transactional
    public ProductResponse createProduct(ProductCreateRequest request) {
        Product product = Product.builder()
                .sku(request.getSku())
                .name(request.getName())
                .description(request.getDescription())
                .price(request.getPrice())
                .active(request.isActive())
                .build();
        Product savedProduct = productRepository.save(product);
        int startingStock = request.getInitialStock() != null ? request.getInitialStock() : defaultInitialStock;
        inventoryRepository.save(InventoryItem.builder()
                .product(savedProduct)
                .availableQuantity(startingStock)
                .build());
        return toResponse(savedProduct);
    }

    public ProductResponse getProduct(Long id) {
        return productRepository.findById(id)
                .map(this::toResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
    }

    public List<ProductResponse> listProducts() {
        return productRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Transactional
    public ProductResponse updateProduct(Long id, ProductUpdateRequest request) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        product.setSku(request.getSku());
        product.setName(request.getName());
        product.setDescription(request.getDescription());
        product.setPrice(request.getPrice());
        product.setActive(request.isActive());
        return toResponse(productRepository.save(product));
    }

    private ProductResponse toResponse(Product product) {
        return ProductResponse.builder()
                .id(product.getId())
                .sku(product.getSku())
                .name(product.getName())
                .description(product.getDescription())
                .price(product.getPrice())
                .active(product.isActive())
                .build();
    }
}
