package com.example.orderservice.domain.enums;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    PENDING
}
