package com.example.orderservice.controller;

import com.example.orderservice.dto.InventoryResponse;
import com.example.orderservice.dto.InventoryUpdateRequest;
import com.example.orderservice.service.InventoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
public class InventoryController {
    private final InventoryService inventoryService;

    @PostMapping("/adjust")
    @ResponseStatus(HttpStatus.OK)
    public InventoryResponse adjustStock(@Valid @RequestBody InventoryUpdateRequest request) {
        return inventoryService.adjustStock(request);
    }

    @GetMapping("/{productId}")
    public InventoryResponse getInventory(@PathVariable Long productId) {
        return inventoryService.getInventory(productId);
    }
}
