package com.example.orderservice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Uniform export envelope (KAN-6). {@code contentType} tells the caller which
 * payload field is populated:
 * <ul>
 *   <li>{@code application/json} &rarr; {@link #orders} holds structured summaries;</li>
 *   <li>{@code text/csv} &rarr; {@link #content} holds the CSV document.</li>
 * </ul>
 * The unused payload field is omitted from the response.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExportResponse {
    private String fileName;
    private String contentType;
    private int recordCount;
    private List<OrderExportSummary> orders;
    private String content;
}
