package com.example.orderservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Flat, report-friendly view of an order used by the export endpoint (KAN-6).
 * Intentionally decoupled from {@code OrderResponse} so the export shape can
 * evolve for reporting/support needs without affecting the transactional API.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderExportSummary {
    private Long id;
    private String orderNumber;
    private Long customerId;
    private String status;
    private BigDecimal totalAmount;
    private int itemCount;
    private LocalDateTime createdAt;
}
