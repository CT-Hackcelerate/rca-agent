package com.example.orderservice.repository;

import com.example.orderservice.domain.entity.InventoryItem;
import com.example.orderservice.domain.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InventoryRepository extends JpaRepository<InventoryItem, Long> {
    Optional<InventoryItem> findByProduct(Product product);
    Optional<InventoryItem> findByProductId(Long productId);
}
