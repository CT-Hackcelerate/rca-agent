package com.example.orderservice;

import com.example.orderservice.dto.CustomerCreateRequest;
import com.example.orderservice.dto.OrderCreateRequest;
import com.example.orderservice.dto.OrderItemRequest;
import com.example.orderservice.dto.ProductCreateRequest;
import com.example.orderservice.service.CustomerService;
import com.example.orderservice.service.OrderService;
import com.example.orderservice.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Web-layer tests for the order export endpoint (KAN-6): JSON and CSV formats,
 * optional date-range filtering, and input validation.
 */
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
// Isolate from the shared named in-memory H2 DB so this MockMvc context does not
// interfere with other test contexts' data/identity sequences.
@TestPropertySource(properties = "spring.datasource.url=jdbc:h2:mem:export-orders-test;DB_CLOSE_DELAY=-1")
class ExportOrdersTest {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private ProductService productService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void seed() {
        Long customerId = customerService.createCustomer(CustomerCreateRequest.builder()
                .name("Ada").email("ada@example.com").phone("5551234").build()).getId();
        Long productId = productService.createProduct(ProductCreateRequest.builder()
                .sku("SKU-EXP").name("Keyboard").price(BigDecimal.valueOf(99)).active(true)
                .initialStock(100).build()).getId();
        orderService.createOrder(OrderCreateRequest.builder()
                .customerId(customerId)
                .shippingStreet("1 Main").shippingCity("London").shippingState("ENG")
                .shippingPostalCode("SW1A").shippingCountry("UK")
                .items(List.of(OrderItemRequest.builder().productId(productId).quantity(2).build()))
                .build());
    }

    @Test
    void defaultFormatIsCsvAndReturnsEnrichedRows() throws Exception {
        mockMvc.perform(get("/api/export/orders"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contentType").value("text/csv"))
                .andExpect(jsonPath("$.recordCount").value(1))
                .andExpect(jsonPath("$.fileName", containsString(".csv")))
                .andExpect(jsonPath("$.content", containsString("id,orderNumber,customerId,status,totalAmount,itemCount,createdAt")))
                .andExpect(jsonPath("$.content", containsString("CREATED")));
    }

    @Test
    void jsonFormatReturnsStructuredSummaries() throws Exception {
        mockMvc.perform(get("/api/export/orders").param("format", "json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contentType").value("application/json"))
                .andExpect(jsonPath("$.recordCount").value(1))
                .andExpect(jsonPath("$.orders[0].customerId").isNumber())
                .andExpect(jsonPath("$.orders[0].status").value("CREATED"))
                .andExpect(jsonPath("$.orders[0].itemCount").value(1))
                .andExpect(jsonPath("$.orders[0].createdAt").exists());
    }

    @Test
    void dateRangeInThePastExcludesRecentOrders() throws Exception {
        mockMvc.perform(get("/api/export/orders")
                        .param("format", "json")
                        .param("fromDate", "2000-01-01T00:00:00")
                        .param("toDate", "2000-12-31T23:59:59"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.recordCount").value(0));
    }

    @Test
    void invertedDateRangeReturns400() throws Exception {
        mockMvc.perform(get("/api/export/orders")
                        .param("fromDate", "2026-12-31T00:00:00")
                        .param("toDate", "2026-01-01T00:00:00"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.message", containsString("fromDate must not be after toDate")));
    }

    @Test
    void unknownFormatReturns400() throws Exception {
        mockMvc.perform(get("/api/export/orders").param("format", "xml"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.message", containsString("Unsupported export format")));
    }
}
