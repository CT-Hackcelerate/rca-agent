package com.example.orderservice;

import com.example.orderservice.dto.CustomerCreateRequest;
import com.example.orderservice.dto.OrderCreateRequest;
import com.example.orderservice.dto.OrderItemRequest;
import com.example.orderservice.dto.ProductCreateRequest;
import com.example.orderservice.dto.ProductResponse;
import com.example.orderservice.service.CustomerService;
import com.example.orderservice.service.InventoryService;
import com.example.orderservice.service.OrderService;
import com.example.orderservice.service.ProductService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Regression tests for KAN-4: a newly created product must be immediately
 * orderable, and an explicit initial stock level must be honoured.
 */
@SpringBootTest
class ProductInventoryInitializationTest {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private InventoryService inventoryService;

    @Test
    void newProductShouldBeOrderableWithoutManualStockAdjustment() {
        customerService.createCustomer(CustomerCreateRequest.builder()
                .name("Grace").email("grace-kan4@example.com").phone("5555").build());
        ProductResponse product = productService.createProduct(ProductCreateRequest.builder()
                .sku("KAN4-SKU-001").name("Keyboard").price(BigDecimal.valueOf(99)).active(true).build());

        // Inventory should be seeded with the configured default (100), not zero.
        assertThat(inventoryService.getInventory(product.getId()).getAvailableQuantity()).isPositive();

        OrderCreateRequest request = OrderCreateRequest.builder()
                .customerId(1L)
                .shippingStreet("1 Main").shippingCity("London").shippingState("ENG")
                .shippingPostalCode("SW1A").shippingCountry("UK")
                .items(List.of(OrderItemRequest.builder().productId(product.getId()).quantity(1).build()))
                .build();

        var response = orderService.createOrder(request);
        assertThat(response.getId()).isNotNull();
        assertThat(response.getStatus()).isEqualTo("CREATED");
    }

    @Test
    void explicitInitialStockShouldBeHonoured() {
        ProductResponse product = productService.createProduct(ProductCreateRequest.builder()
                .sku("KAN4-SKU-002").name("Mouse").price(BigDecimal.valueOf(25)).active(true)
                .initialStock(7).build());

        assertThat(inventoryService.getInventory(product.getId()).getAvailableQuantity()).isEqualTo(7);
    }
}
