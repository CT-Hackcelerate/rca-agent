package com.example.orderservice;

import com.example.orderservice.dto.CustomerCreateRequest;
import com.example.orderservice.dto.OrderCreateRequest;
import com.example.orderservice.dto.OrderItemRequest;
import com.example.orderservice.dto.ProductCreateRequest;
import com.example.orderservice.service.CustomerService;
import com.example.orderservice.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Regression test for KAN-5: ordering more quantity than is available must
 * return a controlled business error (HTTP 409) with a clear message, not an
 * internal exception / unfriendly error.
 */
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
// Isolate from the shared named in-memory H2 DB so this MockMvc context does not
// interfere with other test contexts' data/identity sequences.
@TestPropertySource(properties = "spring.datasource.url=jdbc:h2:mem:insufficient-stock-test;DB_CLOSE_DELAY=-1")
class InsufficientStockTest {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private ProductService productService;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void orderingMoreThanAvailableReturnsControlledConflict() throws Exception {
        customerService.createCustomer(CustomerCreateRequest.builder()
                .name("Ivy").email("ivy@example.com").phone("5555").build());
        productService.createProduct(ProductCreateRequest.builder()
                .sku("SKU-STOCK").name("Widget").price(BigDecimal.valueOf(10)).active(true)
                .initialStock(5).build());

        OrderCreateRequest request = OrderCreateRequest.builder()
                .customerId(1L)
                .shippingStreet("1 Main").shippingCity("London").shippingState("ENG")
                .shippingPostalCode("SW1A").shippingCountry("UK")
                .items(List.of(OrderItemRequest.builder().productId(1L).quantity(50).build()))
                .build();

        mockMvc.perform(post("/api/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.status").value(409))
                .andExpect(jsonPath("$.message").value(containsString("Insufficient stock")))
                .andExpect(jsonPath("$.timestamp").exists());
    }
}
