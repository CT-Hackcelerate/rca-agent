package com.example.orderservice;

import com.example.orderservice.dto.CustomerCreateRequest;
import com.example.orderservice.service.CustomerService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class CustomerServiceTest {
    @Autowired
    private CustomerService customerService;

    @Test
    void shouldCreateAndReadCustomer() {
        CustomerCreateRequest request = CustomerCreateRequest.builder()
                .name("Ada Lovelace")
                .email("ada@example.com")
                .phone("123456")
                .build();

        var response = customerService.createCustomer(request);

        assertThat(response.getId()).isNotNull();
        assertThat(response.getEmail()).isEqualTo("ada@example.com");
    }
}
