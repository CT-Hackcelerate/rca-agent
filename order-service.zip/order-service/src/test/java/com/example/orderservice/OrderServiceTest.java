package com.example.orderservice;

import com.example.orderservice.dto.CustomerCreateRequest;
import com.example.orderservice.dto.OrderCreateRequest;
import com.example.orderservice.dto.OrderItemRequest;
import com.example.orderservice.dto.ProductCreateRequest;
import com.example.orderservice.service.CustomerService;
import com.example.orderservice.service.OrderService;
import com.example.orderservice.service.ProductService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class OrderServiceTest {
    @Autowired
    private CustomerService customerService;

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    @Test
    void shouldCreateOrderWithInventoryReservation() {
        customerService.createCustomer(CustomerCreateRequest.builder().name("Grace").email("grace@example.com").phone("5555").build());
        productService.createProduct(ProductCreateRequest.builder().sku("SKU-001").name("Keyboard").price(BigDecimal.valueOf(99)).active(true).build());

        OrderCreateRequest request = OrderCreateRequest.builder()
                .customerId(1L)
                .shippingStreet("1 Main")
                .shippingCity("London")
                .shippingState("ENG")
                .shippingPostalCode("SW1A")
                .shippingCountry("UK")
                .items(List.of(OrderItemRequest.builder().productId(1L).quantity(1).build()))
                .build();

        var response = orderService.createOrder(request);
        assertThat(response.getId()).isNotNull();
        assertThat(response.getStatus()).isEqualTo("CREATED");
    }
}
