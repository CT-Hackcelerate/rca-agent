# Order Service

A production-style order management microservice built with **Spring Boot 3.3.1** and **Java 21**. It exposes a REST API for managing customers, products, inventory, and orders, including inventory reservation on order creation and CSV export of orders.

---

## Tech stack

| Concern        | Technology                                      |
| -------------- | ----------------------------------------------- |
| Language       | Java 21                                          |
| Framework      | Spring Boot 3.3.1 (Web, Data JPA, Validation)   |
| Persistence    | Spring Data JPA over H2 (in-memory)             |
| Build          | Maven                                            |
| Boilerplate    | Lombok                                           |
| Validation     | Jakarta Bean Validation                          |
| Testing        | JUnit 5 + Spring Boot Test + AssertJ            |

---

## Architecture

A single-module monolith with a classic layered architecture:

```
Client
  → Controller (REST, request validation)
    → Service (business logic, @Transactional)
      → Repository (Spring Data JPA)
        → H2 in-memory database
```

- Domain exceptions are translated into consistent JSON error responses by a single `@RestControllerAdvice` (`GlobalExceptionHandler`).
- Request/response payloads are decoupled from JPA entities via DTOs.

### Order-creation data flow (primary use case)

1. `POST /api/orders` → `OrderController.createOrder`
2. `OrderService` loads the `Customer`, builds an `Order` with a UUID order number and an embedded shipping `Address`.
3. For each line item: loads the `Product` → `InventoryService.reserveStock` decrements available stock (throws `InsufficientStockException` / HTTP 409 if short) → computes the line total.
4. Sums `totalAmount`, cascade-saves the `Order` and its `OrderItem`s, and returns an `OrderResponse`.

---

## Project structure

Base package: `com.example.orderservice`

```
src/main/java/com/example/orderservice/
├── OrderServiceApplication.java     # Spring Boot entry point
├── controller/                      # REST controllers (Order, Product, Customer, Inventory, Export)
├── service/                         # Business logic + transactions
├── repository/                      # Spring Data JPA repositories
├── domain/
│   ├── entity/                      # JPA entities (BaseEntity, Customer, Product, Order, OrderItem, InventoryItem)
│   ├── enums/                       # OrderStatus, CustomerStatus
│   └── value/                       # Address (@Embeddable value object)
├── dto/                             # Request/response DTOs + ErrorResponse
├── exception/                       # ResourceNotFoundException, InsufficientStockException
└── config/                          # GlobalExceptionHandler
src/main/resources/application.yml   # Configuration
src/test/java/...                    # Service-layer tests
```

### Domain model

- **Customer** — name, unique email, phone, status (`ACTIVE`/`INACTIVE`/`PENDING`), one-to-many orders.
- **Product** — unique SKU, name, description, price, active flag.
- **InventoryItem** — one-to-one with a product, tracks `availableQuantity`.
- **Order** — UUID order number, customer, status, created timestamp, embedded shipping `Address`, total amount, order items.
- **OrderItem** — product, quantity, unit price, line total.
- **OrderStatus** — `CREATED` → `CONFIRMED` → `SHIPPED` → `DELIVERED` / `CANCELLED`.

---

## API reference

Base URL: `http://localhost:8081`

### Customers — `/api/customers`

| Method | Path      | Description                          |
| ------ | --------- | ------------------------------------ |
| POST   | `/`       | Create a customer (unique email)     |
| GET    | `/{id}`   | Get a customer                       |
| GET    | `/`       | List customers                       |
| PUT    | `/{id}`   | Update a customer                    |
| DELETE | `/{id}`   | Delete a customer                    |

### Products — `/api/products`

| Method | Path      | Description                                   |
| ------ | --------- | --------------------------------------------- |
| POST   | `/`       | Create a product (auto-creates inventory @ 0) |
| GET    | `/{id}`   | Get a product                                 |
| GET    | `/`       | List products                                 |
| PUT    | `/{id}`   | Update a product                              |

### Inventory — `/api/inventory`

| Method | Path            | Description                              |
| ------ | --------------- | ---------------------------------------- |
| POST   | `/adjust`       | Add/remove stock for a product           |
| GET    | `/{productId}`  | Get current available quantity           |

### Orders — `/api/orders`

| Method | Path                 | Description                                     |
| ------ | -------------------- | ----------------------------------------------- |
| POST   | `/`                  | Create an order (reserves inventory, totals)    |
| GET    | `/{id}`              | Get an order                                    |
| GET    | `/`                  | List orders                                     |
| PATCH  | `/{id}/status?status=SHIPPED` | Update order status                    |

### Export — `/api/export`

| Method | Path          | Description                                    |
| ------ | ------------- | ---------------------------------------------- |
| GET    | `/orders`     | Export orders as JSON or CSV (KAN-6)           |

Query parameters (all optional):

| Param      | Values                     | Default | Description                                             |
| ---------- | -------------------------- | ------- | ------------------------------------------------------- |
| `format`   | `csv` \| `json`            | `csv`   | Output format.                                          |
| `fromDate` | ISO date-time              | —       | Inclusive lower bound on order `createdAt`. Omit = open. |
| `toDate`   | ISO date-time              | —       | Inclusive upper bound on order `createdAt`. Omit = open. |

- When both dates are omitted, **all** orders are exported.
- ISO date-time format, e.g. `2026-01-01T00:00:00`.
- `fromDate` after `toDate`, or an unknown `format`, returns **400** with the standard error body.

Both formats return the same envelope; `contentType` indicates which payload field is populated (`orders` for JSON, `content` for CSV):

**JSON** (`GET /api/export/orders?format=json`):

```json
{
  "fileName": "orders-export-20260715120000.json",
  "contentType": "application/json",
  "recordCount": 1,
  "orders": [
    {
      "id": 1,
      "orderNumber": "a1b2c3d4-...",
      "customerId": 1,
      "status": "CREATED",
      "totalAmount": 198.00,
      "itemCount": 1,
      "createdAt": "2026-07-15T12:00:00"
    }
  ]
}
```

**CSV** (`GET /api/export/orders?format=csv`) — `content` holds the document:

```
id,orderNumber,customerId,status,totalAmount,itemCount,createdAt
1,a1b2c3d4-...,1,CREATED,198.00,1,2026-07-15T12:00:00
```

Example — export all orders created in 2026 as CSV:

```bash
curl "http://localhost:8081/api/export/orders?format=csv&fromDate=2026-01-01T00:00:00&toDate=2026-12-31T23:59:59"
```

### Example requests

Create a customer:

```bash
curl -X POST http://localhost:8081/api/customers \
  -H "Content-Type: application/json" \
  -d '{"name":"Ada Lovelace","email":"ada@example.com","phone":"5551234"}'
```

Create a product:

```bash
curl -X POST http://localhost:8081/api/products \
  -H "Content-Type: application/json" \
  -d '{"sku":"SKU-001","name":"Keyboard","description":"Mechanical","price":99.00,"active":true}'
```

Add stock:

```bash
curl -X POST http://localhost:8081/api/inventory/adjust \
  -H "Content-Type: application/json" \
  -d '{"productId":1,"quantity":50}'
```

Create an order:

```bash
curl -X POST http://localhost:8081/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerId":1,
    "shippingStreet":"1 Main St",
    "shippingCity":"London",
    "shippingState":"ENG",
    "shippingPostalCode":"SW1A",
    "shippingCountry":"UK",
    "items":[{"productId":1,"quantity":2}]
  }'
```

### Error responses

Errors return a consistent JSON body:

```json
{ "message": "...", "status": 404, "timestamp": "2026-07-11T16:00:00Z" }
```

| Scenario                    | HTTP status |
| --------------------------- | ----------- |
| Resource not found          | 404         |
| Insufficient stock          | 409         |
| Request validation failure  | 400         |

---

## Configuration

From `src/main/resources/application.yml`:

| Setting        | Value                                                        |
| -------------- | ----------------------------------------------------------- |
| Database       | H2 in-memory (`jdbc:h2:mem:orderservice`)                   |
| Schema         | `ddl-auto: create-drop` (recreated on every startup)        |
| SQL logging    | `show-sql: true`                                             |
| H2 console     | Enabled at `/h2-console`                                     |
| Server port    | `PORT` env var, defaults to `8081`                          |

No external services, secrets, or Spring profiles are required — the service runs fully self-contained. All data is in-memory and reset on every restart.

---

## Getting started

### Prerequisites

- JDK 21
- Maven 3.9+

### Run

```bash
mvn spring-boot:run
# Service starts on http://localhost:8081
```

Override the port:

```bash
PORT=9090 mvn spring-boot:run
```

### Test

```bash
mvn test
```

### Build a jar

```bash
mvn clean package
java -jar target/order-service-1.0.0-SNAPSHOT.jar
```

---

## Known gaps / tech debt

- **In-memory H2 only** — no persistent datastore or environment-specific profiles; data is lost on restart.
- **No stock release on cancel** — `reserveStock` decrements inventory on order creation, but cancelling an order does not restore stock.
- **Export scans all orders in memory** — `ExportService` loads every order and filters by date in Java; date filtering should be pushed down to a repository query.
- **No pagination** on list endpoints.
- **No authentication/authorization** — all endpoints (and the H2 console) are open.
- **Order status transitions are unguarded** — any status can transition to any other; no state-machine validation.
- **Thin test coverage** — only happy-path service tests; no web-layer or error-path tests.
- The `target/` build directory is currently committed and should be git-ignored.
